<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <title>Add Coupon</title>
</head>

<body class="container">
    <div class="row">
        <div class="col-md-12 text-center">
            <h1>My Cart</h1>
        </div>
        <?php if($coupon == 'no coupon'){ ?>
        <div class="col-md-7" style="border-radius: 10px; border: 2px solid black;">
            <div class="row">
                <?php $total = 0; $count = 0; foreach($cartData as $data){ ?>
                <div class="col-md-2">
                    <img src="<?php echo base_url(); ?>public/<?php echo $data->product_image; ?>" alt="" height="100px" width="100px">
                </div>
                <div class="col-md-6">
                    <p><?php echo $data->product_name; ?></p>
                    <p>Qty : <?php echo $data->count_added; ?></p>
                    <?php $count+=$data->count_added; ?>
                </div>
                <div class="col-md-4">
                    <p style="text-align:right;margin: 10px 20px;">&#8377;<?php echo $price = $data->count_added*$data->price; ?>.00</p>
                    <?php $total+=$price; ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php }else{ ?>
        <div class="col-md-7" style="border-radius: 10px; border: 2px solid black;">
            <h4>Coupon Eligible Products</h4>
            <div class="row">
                <?php $total = 0; $total1 =0; $count = 0; foreach($discountProducts2 as $data){ ?>
                <div class="col-md-2">
                    <img src="<?php echo base_url(); ?>public/<?php echo $data->product_image; ?>" alt="" height="100px" width="100px">
                </div>
                <div class="col-md-6">
                    <p><?php echo $data->product_name; ?></p>
                    <p>Qty : <?php echo $data->count_added; ?></p>
                    <?php $count+=$data->count_added; ?>
                </div>
                <div class="col-md-4">
                    <p style="text-align:right;margin: 10px 20px;">&#8377;<?php echo number_format($data->discountedAmount,2); ?><del> &#8377;<?php $price = $data->count_added*$data->price; echo number_format($price,2); ?></del></p>
                    <?php $price1 = $data->discountedAmount; ?>
                    <?php $total+=$price; $total1+=$price1; ?>
                </div>
                <?php } ?>
            </div>
            <h4>Coupon Not Eligible Products</h4>
            <div class="row">
                <?php $total2 = 0; $count2 = 0; foreach($notDiscountProducts as $data){ ?>
                <div class="col-md-2">
                    <img src="<?php echo base_url(); ?>public/<?php echo $data->product_image; ?>" alt="" height="100px" width="100px">
                </div>
                <div class="col-md-6">
                    <p><?php echo $data->product_name; ?></p>
                    <p>Qty : <?php echo $data->count_added; ?></p>
                    <?php $count2+=$data->count_added; ?>
                </div>
                <div class="col-md-4">
                    <p style="text-align:right;margin: 10px 20px;">&#8377;<?php $price = $data->count_added*$data->price;  echo number_format($price,2);?></p>
                    <?php $total2+=$price; ?>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php }?>
        <div class="col-md-1">
            &nbsp;
        </div>
        <div class="col-md-4" style="border-radius: 10px; border: 2px solid black;">
            <h3>PRICE DETAILS</h3>
            <div class="row">
                <?php if($coupon == 'no coupon'){ ?>
                <div class="col-md-6">
                    <p>Price (<?php echo $count; ?> item)</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">&#8377; <?php echo number_format($total,2); ?></p>
                </div>
                <div class="col-md-6">
                    <p>Discount</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">&#8377; 0.00</p>
                </div>
                <div class="col-md-6">
                    <p>Delivery Charges</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">Free <del>&#8377; 149.00</del></p>
                </div>
                <div class="col-md-6">
                    <p>Total</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">&#8377; <?php echo number_format($total,2); ?></p>
                </div>
                <?php }else{ ?>
                    <div class="col-md-6">
                    <p>Price (<?php echo $count+$count2; ?> item)</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">&#8377; <?php echo $abc1 = number_format($total+$total2,2); ?></p>
                </div>
                <div class="col-md-6">
                    <p>Discount</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">- &#8377; <?php echo $abc2 = number_format(($total+$total2)-($total1+$total2),2); ?></p>
                </div>
                <div class="col-md-6">
                    <p>Delivery Charges</p>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right">Free <del>&#8377; 149.00</del></p>
                </div>
                <div class="col-md-6">
                    <p>Total</p>
                </div>
                <div class="col-md-6">
                    <?php
                        $a = $total+$total2;
                        $b = $a-($total1+$total2);
                        $c = $a-$b;
                    ?>
                    <p style="text-align: right">&#8377; <?php echo number_format($c,2); ?></p>
                </div>
                <?php } ?>
                <div class="col-md-12">
                    <h4>Enter Coupon Code</h4>
                    <form action="" method="post">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Enter Coupon Code" id="couponCode" name="couponCode" value="<?= set_value('couponCode'); ?>" required>
                            <input class="btn btn-outline-secondary" type="submit" id="submit" value="Apply">
                        </div>
                        <span><?php echo $couponStatus; ?></span>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>