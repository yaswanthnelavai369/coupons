<?php

namespace App\Controllers;

use App\Models\WelcomeModel;

class Home extends BaseController
{
    public $welcomeModel;
    public function __construct()
    {
        helper('form');
        helper(['form']);
        $this->welcomeModel = new WelcomeModel();
    }

    public function index()
    {
        return view('welcome_message');
    }

    public function addCoupon()
    {
        $data['success'] = NULL;
        $data['categoryData'] = $this->welcomeModel->getAllCategoryData();
        $data['brandData'] = $this->welcomeModel->getAllBrandData();
        if($this->request->getMethod() == 'POST'){
            $insertData = [
                "coupon_id"         => $this->request->getVar('couponId'),
                "coupon_name"       => $this->request->getVar('couponName'),
                "coupon_type"       => $this->request->getVar('couponType'),
                "coupon_value"      => $this->request->getVar('couponValue'),
                "minimum_price"     => $this->request->getVar('mceAmount'),
                "coupon_count"      => $this->request->getVar('couponCount'),
                "coupon_specified"  => $this->request->getVar('specificUser'),
                "coupon_duration"   => $this->request->getVar('couponLastDate'),
                "in_category"       => json_encode($this->request->getVar('inCategoryList')),
                "not_category"      => json_encode($this->request->getVar('notCategoryList')),
                "in_brand"          => json_encode($this->request->getVar('inBrandList')),
                "not_brand"         => json_encode($this->request->getVar('notBrandList')),
            ];
            // echo "<pre>";
            // var_dump($insertData);
            // echo "</pre>";
            // die;
            $addCoupon = $this->welcomeModel->addCouponDetails($insertData);
            if($addCoupon){
                $data['success'] = 'Coupon added Successfully';
            }
            // var_dump($addCoupon);
            // die;
            // $couponId = $this->request->getVar('couponId');
            // $couponId = $this->request->getVar('couponId');
            // $couponId = $this->request->getVar('couponId');
        }
        echo view('add_coupon',$data);
    }

    public function cart()
    {
        $data['cartData'] = $this->welcomeModel->getAllCartData();
        $data['coupon'] = 'no coupon';
        $data['couponStatus'] = NULL;
        $data['discountProducts'] = [];
        $data['discountProducts2'] = [];
        $data['notDiscountProducts'] = [];
        $data['newShuffleArray'] = [];
        $data['newShuffleArray2'] = [];
        if($this->request->getMethod() == 'POST'){
            $data['coupon'] = 'no coupon';
            $couponCode = $this->request->getVar('couponCode');
            $couponData = $this->welcomeModel->getCouponData($couponCode);
            if($couponData['coupon_duration'] <= date('Y-m-d')){ 
                $data['couponStatus'] = 'Coupon Expried!'; 
            }else{
                if($couponData['coupon_count'] <= $couponData['coupon_used_count']){ 
                    $data['couponStatus'] = 'Coupon Already Used!'; 
                }else{
                    $i=0;
                    
                    foreach($data['cartData'] as $value){
                        if($couponData['in_category'] != ''){
                            $in_category = json_decode($couponData['in_category']);
                            $j=0;
                            while($j<count($in_category)){
                                if($data['cartData'][$i]->category == $in_category[$j]){
                                    $data['discountProducts'][] = $data['cartData'][$i];
                                }
                            $j++;}
                        }elseif($couponData['not_category'] != ''){
                            $not_category = json_decode($couponData['not_category']);
                            $j=0;
                            while($j<count($not_category)){
                                if($data['cartData'][$i]->category != $not_category[$j]){
                                    //empty
                                }else{
                                    $data['discountProducts'][] = $data['cartData'][$i];
                                }
                            $j++;}
                        }else{
                            //empty
                        }
                    $i++;}
                    if($couponData['not_category'] != ''){
                        foreach ($data['cartData'] as $itemA1) {
                            $found = false;
                            foreach ($data['discountProducts'] as $itemA2) {
                                if ($itemA1->id === $itemA2->id) {
                                    $found = true;
                                    break;
                                }
                            }
                            if (!$found) {
                                $data['newShuffleArray'][] = $itemA1;
                            }
                        }
                        $data['discountProducts'] = $data['newShuffleArray'];
                        // print_r($data['discountProducts']);
                        // die;
                    }
                    $i=0;
                    foreach($data['discountProducts'] as $value){
                        if($couponData['in_brand'] != ''){
                            $in_brand = json_decode($couponData['in_brand']);
                            $j=0;
                            while($j<count($in_brand)){
                                if($data['discountProducts'][$i]->brand == $in_brand[$j]){
                                    $data['discountProducts2'][] = $data['discountProducts'][$i];
                                }
                            $j++;}
                        }elseif($couponData['not_brand'] != ''){
                            $not_brand = json_decode($couponData['not_brand']);
                            $j=0;
                            while($j<count($not_brand)){
                                if($data['discountProducts'][$i]->category != $not_brand[$j]){
                                    //empty
                                }else{
                                    $data['discountProducts2'][] = $data['discountProducts'][$i];
                                }
                            $j++;}
                        }else{
                            $data['discountProducts2'] = $data['discountProducts'];
                        }
                        $i++;
                    }
                    if($couponData['not_brand'] != ''){
                        foreach ($data['cartData'] as $itemA1) {
                            $found = false;
                            foreach ($data['discountProducts2'] as $itemA2) {
                                if ($itemA1->id === $itemA2->id) {
                                    $found = true;
                                    break;
                                }
                            }
                            if (!$found) {
                                $data['newShuffleArray2'][] = $itemA1;
                            }
                        }
                        $data['discountProducts2'] = $data['newShuffleArray2'];
                    }
                    if($couponData['in_category'] == '' && $couponData['not_category'] == '' && $couponData['in_brand'] == '' && $couponData['not_brand'] == ''){
                        $data['discountProducts2'] = $data['cartData'];
                    }else{
                        foreach ($data['cartData'] as $itemA1) {
                            $found = false;
                            foreach ($data['discountProducts2'] as $itemA2) {
                                if ($itemA1->id === $itemA2->id) {
                                    $found = true;
                                    break;
                                }
                            }
                            if (!$found) {
                                $data['notDiscountProducts'][] = $itemA1;
                            }
                        }
                    }
                    if(empty($data['discountProducts2'])){
                        $data['couponStatus'] = 'No Coupon Eligible Products in Cart';
                    }else{
                        $k=0;
                        $finalGrandTotal = 0;
                        foreach($data['discountProducts2'] as $final){
                            $grandtotal = $final->count_added*$final->price;
                            $data['discountProducts2'][$k]->grandtotal = $grandtotal;
                            $finalGrandTotal+=$grandtotal;
                        $k++;}
                        if($couponData['minimum_price'] > $finalGrandTotal){ 
                            $data['couponStatus'] = 'To apply Coupon Minimum Amount should be '.$couponData['minimum_price'];
                        }else{
                            if($couponData['coupon_type'] == 'percentage'){
                                $z=0;
                                foreach($data['discountProducts2'] as $product){
                                    $discountedAmount = ($couponData['coupon_value']/100)*$product->grandtotal;
                                    $data['discountProducts2'][$z]->discountedAmount = $discountedAmount;
                                }
                            $z++;}else{
                                $z=0;
                                foreach($data['discountProducts2'] as $product){
                                    $discount1 = ($product->grandtotal / $finalGrandTotal) * $couponData['coupon_value'];
                                    $discountedAmount = $product->grandtotal-$discount1;
                                    $data['discountProducts2'][$z]->discountedAmount = $discountedAmount;
                            $z++;}
                            }
                            $data['coupon'] = 'coupon';
                            // echo "<pre>";
                            // // var_dump($data['cartData']);
                            // echo "discountProducts";
                            // echo "<br>";
                            // echo $finalGrandTotal;
                            // echo "<br>";
                            // var_dump($data['discountProducts2']);
                            // echo "notDiscountProducts";
                            // echo "<br>";
                            // var_dump($data['notDiscountProducts']);
                            // echo "</pre>";
                        }
                    }
                }
            }
        }
        echo view('cart',$data);
    }
}
