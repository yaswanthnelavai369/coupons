<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/add-coupon', 'Home::addCoupon');
$routes->post('/add-coupon', 'Home::addCoupon');
$routes->get('/cart', 'Home::cart');
$routes->post('/cart', 'Home::cart');
