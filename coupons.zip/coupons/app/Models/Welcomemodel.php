<?php

    namespace App\Models;

    use CodeIgniter\Model;

    class WelcomeModel extends Model {
        public function getAllCategoryData(){
            $table = $this->db->query('select * from categories');
            $result = $table->getResult();
            if(count($result) > 0 ){
                return $result;
            }else{
                return false;
            }
        }
        public function getAllBrandData(){
            $table = $this->db->query('select * from brands');
            $result = $table->getResult();
            if(count($result) > 0 ){
                return $result;
            }else{
                return false;
            }
        }
        public function addCouponDetails($data){
            $table = $this->db->table('coupons');
            $result = $table->insert($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
        }
        public function getAllCartData(){
            $table = $this->db->query('select * from products');
            $result = $table->getResult();
            if(count($result) > 0 ){
                return $result;
            }else{
                return false;
            }
        }
        public function getCouponData($id){
            $table = $this->db->table('coupons');
            $table->select('*');
            $table->where('coupon_id', $id);
            $result = $table->get();
            if(count($result->getResultArray()) > 0){
                return $result->getRowArray();
            }else{
                return false;
            }
        }






        






        // roles
        
        
         
        
         public function updateRoleDetails($id, $data){
            $table = $this->db->table('admin_roles');
            $table->where('id', $id);
            $result = $table->update($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
         }
        
         public function getAllRolesData(){
            $table = $this->db->query('select * from admin_roles');
            $result = $table->getResult();
            if(count($result) > 0 ){
                return $result;
            }else{
                return false;
            }
         }
        
         public function deleteRolebyId($id, $status){
            $table = $this->db->table('admin_roles');
            $table->where('id', $id);
            if($status == 0){
                $result = $table->update(['status'=>1]);
            }
            if($status == 1){
                $result = $table->update(['status'=>0]);
            }
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
            
         }
// users
            public function verifyEmailInAdminLogin($data){
                $table = $this->db->table('admin_login');
                $table->select('*');
                $table->where('email', $data);
                $result = $table->get();
                if(count($result->getResultArray()) == 1){
                    return $result->getRowArray();
                }else{
                    return false;
                }
            }
        
         public function addUserData($data){
            $table = $this->db->table('admin_login');
            $result =$table->insert($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
          }
         
         public function getAllUserData(){
            $table = $this->db->query('select * from admin_login');
            $result  = $table->getResult();
            if(count($result) > 0){
                return $result;
            }else{
                return false;
            }
         } 
        
         public function getUserDataById($id){
            $table = $this->db->table('admin_login');
            $table->select('*');
            $table->where('id', $id);
            $result = $table->get();
            if(count($result->getResultArray()) == 1){
                return $result->getRowArray();
            }else{
                return false;
            }
         }
        
         public function updateUserData($id, $data){
            $table = $this->db->table('admin_login');
            $table->where('id', $id);
            $result = $table->update($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
         } 
        
         public function deleteUserById($id, $status){
            $table = $this->db->table('admin_login');
            $table->where('id', $id);
            if($status == 1){
                $result = $table->update(['status'=>0]);
            }
            if($status == 0){
                $result = $table->update(['status'=>1]);
        
            }
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
         }

         public function getUserSearchData($search){
            $table = $this->db->table('admin_login');
            $table->like('username', $search)->orLike('email', $search);
            $result = $table->get();
            // $a = $this->db->getLastQuery();echo $a; die;
            if(count($result->getResult()) > 0){
                return $result->getResult();
            }else{
                return false;
            }
         }

         public function verifyUserIdInAdminLogin($id){
            $adminTable = $this->db->table('admin_login');
            $adminTable->select("*");
            $adminTable->where('id',$id);
            $result = $adminTable->get();
            // $a = $this->db->getLastQuery(); echo $a; die;
            if(count($result->getResultArray()) == 1){
                return $result->getRowArray();
            }else{
                return false;
            }
        }

        public function updateAdmin_LoginTablePassword($email, $hash){
            $table = $this->db->table('admin_login');
            $table->where('email', $email);
            $result = $table->update(['password'=>$hash]);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
        }

        public function allPersonalDetails() {
            $adminTable = $this->db->table('personal_details');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allEducationalDetails() {
            $adminTable = $this->db->table('educational_details');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allPreviousEducationalDetails() {
            $adminTable = $this->db->table('previous_education');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allFamilyDetails() {
            $adminTable = $this->db->table('family_details');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allFeeStuctureDetails() {
            $adminTable = $this->db->table('fee_structure');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allBankDetails() {
            $adminTable = $this->db->table('bank_details');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function allDeclartions() {
            $adminTable = $this->db->table('declartion');
            $query = $adminTable->get();
            $result = $query->getResultArray();
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }

        public function updateCategory($id, $data){
            $table = $this->db->table('declartion');
            $table->where('user_id', $id);
            $result = $table->update($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
        }

        public function updateapproval($id, $data){
            $table = $this->db->table('declartion');
            $table->where('user_id', $id);
            $result = $table->update($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
        }

        public function getCompleteStudentsData($query){
            $table = $this->db->query($query);
            $result = $table->getResult();
            if(count($result) > 0 ){
                return $result;
            }else{
                return false;
            }
         }

         public function addFileToDb($data){
            $table = $this->db->table('file_data');
            $result = $table->insert($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
         }

         public function addLog($data){
            $table = $this->db->table('logs');
            $result = $table->insert($data);
            if($this->db->affectedRows() == 1){
                return true;
            }else{
                return false;
            }
         }
        //  public function allLogs($id){
        //     $table = $this->db->table('logs');
        //     $table->select('*');
        //     $table->where('user_id', $id);
        //     $result = $table->get();
        //     // $a = $this->db->getLastQuery(); echo $a; die;
        //     if(count($result->getResultArray()) > 0){
        //         $result->getRowArray();
        //     }else{
        //         return false;
        //     }
        //  }
         public function allLogs($id) {
            $adminTable = $this->db->table('logs');
            $adminTable->where('user_id', $id);
            $query = $adminTable->get();
            $result = $query->getResultArray();
            // $a = $this->db->getLastQuery(); echo $a; die;
            if (!empty($result)) {
                return $result;
            } else {
                return [];
            }
        }
        public function getAdminById($id){
            $table = $this->db->table('admin_login');
            $table->select('*');
            $table->where('id', $id);
            $result = $table->get();
            if(count($result->getResultArray()) == 1){
                return $result->getRowArray();
            }else{
                return false;
            }
        }
    }

?>